## Documentation: Credits

Maintaining documentation is a lot of work, and we are proud of it.
Shameless plugs are certainly not out of order :)

### Authors

* **Marshall Sorenson**
	* Website: <a href="http://marshallsorenson.com/" target="_blank">http://marshallsorenson.com/</a>
	* Twitter: <a href="http://twitter.com/mazftw" target="_blank">@mazftw</a>

* **Bowe Frankema**
	* Website: <a href="http://bp-tricks.com/" target="_blank">http://bp-tricks.com/</a>
	* Twitter: <a href="http://twitter.com/BoweFrankema" target="_blank">@BoweFrankema</a>

### Help!

> If you want to help with the documentation by adding to it, or improving upon it, please
get in touch with us!